// ------------------------------------------------------------------------------
// DATOS Y ENCABEZADO
//-------------------------------------------------------------------------------
    
/* 
 * File: adc.h
 * Author: Gustabo Córdova
 * Comments: //
 * Revision history: // 
 */

#ifndef ADC_H
#define	ADC_H
#ifndef _XTAL_FREQ 
#define _XTAL_FREQ 8000000  
                               
#endif

// ------------------------------------------------------------------------------
// LIBRERÍAS
//-------------------------------------------------------------------------------
#include <stdint.h>
#include <xc.h>
#include "ADC.h"

// ------------------------------------------------------------------------------
// PROTOTIPOS DE FUNCIÓN
//-------------------------------------------------------------------------------

void adc_init (uint8_t adc_cs, uint8_t vref_plus, uint8_t vref_minus);
void adc_start (uint8_t channel);
uint16_t adc_read (void);


#endif	/* ADC_H */




