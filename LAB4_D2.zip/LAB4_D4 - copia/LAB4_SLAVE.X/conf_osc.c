// ------------------------------------------------------------------------------
// DATOS Y ENCABEZADO
//-------------------------------------------------------------------------------
    
/* 
 * File: conf_osc.c
 * Author: Gustabo Córdova
 * Comments: //
 * Revision history: // 
 */

//-----------------------------------------------------------------------------------------------------------------------------------------------
// LIBRERIAS
//-----------------------------------------------------------------------------------------------------------------------------------------------

#include <stdint.h>
#include <pic16f887.h>
#include "conf_osc.h"

// ------------------------------------------------------------------------------
// SELECCIÓN DE FRECUENCIA
//-------------------------------------------------------------------------------

void int_osc_MHz (uint8_t frec)
{
    switch (frec){
        case 0:
            OSCCONbits.IRCF0 = 0;   // 1 MHz
            OSCCONbits.IRCF1 = 0;
            OSCCONbits.IRCF2 = 1;
            break;
        case 1:
            OSCCONbits.IRCF0 = 1;   // 2 MHz
            OSCCONbits.IRCF1 = 0;
            OSCCONbits.IRCF2 = 1;
            break;
        case 2:
            OSCCONbits.IRCF0 = 0;   // 4 MHz
            OSCCONbits.IRCF1 = 1;
            OSCCONbits.IRCF2 = 1;
            break;
        case 3:
            OSCCONbits.IRCF0 = 1;   // 8 MHz
            OSCCONbits.IRCF1 = 1;
            OSCCONbits.IRCF2 = 1;
            break;
        default:
            OSCCONbits.IRCF0 = 0;   // 2 MHz
            OSCCONbits.IRCF1 = 1;
            OSCCONbits.IRCF2 = 1;
    
    }
    OSCCONbits.SCS = 1;             // Activación del relok interno

}



