// ------------------------------------------------------------------------------
// DATOS Y ENCABEZADO
//-------------------------------------------------------------------------------
    
/* 
 * File: interrupciones.c
 * Author: Gustabo C�rdova
 * Comments: //
 * Revision history: // 
 */

// ------------------------------------------------------------------------------
// LIBRER�AS
//-------------------------------------------------------------------------------
#include "Interrupciones.h"

// ------------------------------------------------------------------------------
// INTERRUPCIONES ON CHANGE
//-------------------------------------------------------------------------------
void ioc_init(char pin){
    TRISB |= (1 << pin);            // Pin como 0/1
    OPTION_REGbits.nRBPU = 0;       // Pull ups individuales
    WPUB |= (1 << pin);             // Se habilita el Pull up
    IOCB |= (1 << pin); 
    INTCONbits.RBIE = 1;            // PORTB Change Interrupt enable bit
    INTCONbits.RBIF = 0;            // PORTB Change Interrupt flag bit
    INTCONbits.GIE = 1;             // Globales
}
