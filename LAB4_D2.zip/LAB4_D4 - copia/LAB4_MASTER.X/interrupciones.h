// ------------------------------------------------------------------------------
// DATOS Y ENCABEZADO
//-------------------------------------------------------------------------------
    
/* 
 * File: interrupciones.h
 * Author: Gustabo C�rdova
 * Comments: //
 * Revision history: // 
 */

  
#ifndef INTERRUPCIONES_H
#define	INTERRUPCIONES_H

#include <xc.h> // include processor files - each processor file is guarded.  

// ------------------------------------------------------------------------------
// FUNCION PARA SETEAR LAS INTERRUPCIONES ON CHANGE
//-------------------------------------------------------------------------------
    
void ioc_init(char pin);

#endif	/* INTERRUPCIONES_H */